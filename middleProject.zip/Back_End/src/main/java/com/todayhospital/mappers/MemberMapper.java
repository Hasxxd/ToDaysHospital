package com.todayhospital.mappers;

import java.util.List;
import com.todayhospital.dto.MemberDTO;

public interface MemberMapper {
    List<MemberDTO> selectAllMembers();
}
