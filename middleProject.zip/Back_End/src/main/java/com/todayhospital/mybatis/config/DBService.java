package com.todayhospital.mybatis.config;

import java.io.Reader;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

/**
 * MyBatis SQL 세션 팩토리 제공 클래스
 * - sqlmap.xml을 읽어 SqlSessionFactory 객체를 생성
 * - 초기화 실패 시 예외 throw 처리
 */
public class DBService {

    private static SqlSessionFactory factory;

    static {
        try {
            String resource = "mybatis.config.xml"; // 클래스패스 기준으로 수정
            Reader reader = Resources.getResourceAsReader(resource);
            factory = new SqlSessionFactoryBuilder().build(reader);
            reader.close();
        } catch (Exception e) {
            System.err.println("MyBatis SqlSessionFactory 초기화 실패: " + e.getMessage());
            throw new RuntimeException("DBService 초기화 실패", e); // 시스템 종료 방지
        }
    }

    public static SqlSessionFactory getFactory() {
        return factory;
    }

    public static SqlSessionFactory SqlSessionFactory() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'SqlSessionFactory'");
    }
}

// package com.todayhospital.config;

// import java.io.InputStream;
// import org.apache.ibatis.io.Resources;
// import org.apache.ibatis.session.SqlSessionFactory;
// import org.apache.ibatis.session.SqlSessionFactoryBuilder;

// public class MyBatisUtil {
// private static SqlSessionFactory sqlSessionFactory;

// static {
// try {
// InputStream inputStream =
// Resources.getResourceAsStream("mybatis-config.xml");
// sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);
// } catch (Exception e) {
// e.printStackTrace();
// }
// }

// public static SqlSessionFactory getSqlSessionFactory() {
// return sqlSessionFactory;
// }
// }
