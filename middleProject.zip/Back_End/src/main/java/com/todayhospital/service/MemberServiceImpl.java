package com.todayhospital.service;

import com.todayhospital.dto.MemberDTO;
// import com.todayhospital.dto.ZipcodeDTO;

public class MemberServiceImpl implements MemberService {

    @Override
    public MemberDTO idCheck(String id) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'idCheck'");
    }

    @Override
    public MemberDTO pwdMember(MemberDTO m) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'pwdMember'");
    }

    @Override
    public MemberDTO loginCheck(String id) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'loginCheck'");
    }

    @Override
    public MemberDTO getMember(String id) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'getMember'");
    }

}