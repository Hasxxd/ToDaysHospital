const hospitals = [
  {
    id: 1,
    name: "서울튼튼병원",
    address: "서울시 강남구 역삼동 123",
    department: "정형외과",
    phone: "02-123-4567"
  },
  {
    id: 2,
    name: "강남삼성의원",
    address: "서울시 강남구 삼성동 456",
    department: "내과",
    phone: "02-987-6543"
  },
  {
    id: 3,
    name: "분당서울대학교병원",
    address: "경기도 성남시 분당구",
    department: "종합병원",
    phone: "031-123-4567"
  }
];
